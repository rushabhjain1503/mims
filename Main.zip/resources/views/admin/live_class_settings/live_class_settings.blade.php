@extends('admin.navigation')

@section('content')
<div class="mainSection-title">
    <div class="row">
        <div class="col-12">
            <div
              class="d-flex justify-content-between align-items-center flex-wrap gr-15"
            >
                <div class="d-flex flex-column">
                    <h4>{{ get_phrase('Live class settings') }}</h4>
                    <ul class="d-flex align-items-center eBreadcrumb-2">
                        <li><a href="#">{{ get_phrase('Home') }}</a></li>
                        <li><a href="#">{{ get_phrase('Settings') }}</a></li>
                        <li><a href="#">{{ get_phrase('Live class') }}</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="eSection-wrap">
            <div class="title">
                <h3>{{ get_phrase('Zoom Key Settings') }}</h3>
            </div>
            <div class="eMain">
                <div class="row">
                    <div class="col-md-6 pb-3">
                        <div class="eForm-layouts">
                            <form method="POST" class="col-12 live-class-settings-form" action="{{ route('admin.live_class_key.update', ['id' => $data[0]->school_id,'type'=> 'zoom']) }}" id="live-class-settings-form">
                                @csrf

                                <div class="fpb-7">
                                    <label for="zoom_api_key" class="eForm-label">{{ get_phrase('Zoom api key') }}</label>
                                    <input type="text" id="zoom_api_key" name="zoom_api_key" class="form-control eForm-control" value="{{ $data[0]->zoom_api_key }}" required>
                                    <input type="hidden" name="school_id " value="{{ $data[0]->school_id }}">
                                    <input type="hidden" name="type" value="zoom">
                                </div>

                                <div class="fpb-7">
                                    <label for="zoom_secret_key" class="eForm-label">{{ get_phrase('Zoom secret key') }}</label>
                                    <input type="text" id="zoom_secrect_key" name="zoom_secrect_key" class="form-control eForm-control" value="{{ $data[0]->zoom_secrect_key }}" required>
                                </div>

                                <div class="fpb-7 pt-2">
                                    <button type="submit" class="btn-form" onclick="">{{ get_phrase('Update info') }}</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
