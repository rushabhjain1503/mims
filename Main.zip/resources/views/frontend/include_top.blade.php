<!-- Favicons -->
<link rel="icon" href="{{ asset('frontend/assets/image/purple_gradient.png') }}">
<!-- Fontawasome Css -->
<link rel="stylesheet" href="{{ asset('frontend/assets/css/all.min.css') }}">
<!-- Bootstarp Css -->
<link rel="stylesheet" href="{{ asset('frontend/assets/css/bootstrap.min.css') }}">
<!-- Main Css -->
<link rel="stylesheet" href="{{ asset('frontend/assets/css/style.css') }}">
<!-- Responsive Css -->
<link rel="stylesheet" href="{{ asset('frontend/assets/css/responsive.css') }}">
<!-- Toaster Css -->
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/toastr.min.css') }}">
