<?php

namespace App\Http\Controllers\Addon;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Addon\CreateZoomMeetings;
use App\Traits\ZoomMeetingTrait;
use Illuminate\Http\Request;
use App\Models\Addon\LiveClassSettings;
use App\Models\User;
use App\Models\Session;
use App\Models\Addon\LiveClasses;
use Illuminate\Support\Facades\DB;
use App\Models\Section;
use App\Models\Enrollment;
use App\Models\Classes;
use App\Models\Subject;
use Carbon\Carbon;


class ZoomLiveClass extends Controller
{
   
    public function live_class_settings()
    {

        $admin_s_School=User::find(auth()->user()->id);
        $data =LiveClassSettings::where('school_id', $admin_s_School['school_id'])->get();

       if(count($data)==0)
       {
         $this->add_zoom_keys();
         $data =LiveClassSettings::where('school_id', $admin_s_School['school_id'])->get();
       }


        return view('admin.live_class_settings.live_class_settings',['data' => $data]);
    }

    public function add_zoom_keys()
    {
        $keys=new LiveClassSettings;
        $keys['zoom_api_key']=" ";
        $keys['zoom_secrect_key']=" ";
        $keys['school_id']=auth()->user()->school_id;
        $keys['updated_at']=strtotime(date('m-d-Y'));
        $keys->save();

    }

    public function live_class_settings_update(Request $request,$school_id)
    {

        $data = $request->all();


        $check =LiveClassSettings::get()->where('school_id',$school_id);
        if(!empty($check->toArray()))
        {


                if($data['type']=="zoom")
                {

                    LiveClassSettings::where('school_id', $school_id)->update([
                    'zoom_api_key' => $data['zoom_api_key'],
                    'zoom_secrect_key' => $data['zoom_secrect_key'],
                ]);
                return redirect()->route('admin.live_class_key')->with('message', 'key has been updated');
                }



        }




    }



    public function add_live_class()
    {
        return view('teacher.live_class.add_new_live_class');
    }

    public function live_class_adding(Request $request)
    {

        $data = $request->all();


        $active_session = Session::where('status', 1)->first();

        if (isset($data['attachment'])) {

            $file = $data['attachment'];


            $filename = "";
            if ($file) {
                $filename = $file->getClientOriginalName();
                $extension = $file->getClientOriginalExtension();

                $file->move(public_path('assets/uploads/live_class/'), $filename);

                $filepath = asset('public/assets/uploads/live_class/' . $filename);
            }
        } else {
            $filename = "";
        }


        $wait = false;


        if (isset($data['waiting_room'])) {
            if ($data['waiting_room'] == 'on') {
                $wait = true;
            }
        }


        $meeting_info['topic'] = $data['topic'];
        $meeting_info['start_time'] = strtotime($data['date']);
        $meeting_info['agenda'] = "unknown";
        $meeting_info['waiting_room'] = $wait;
        $status = (new CreateZoomMeetings)->create($meeting_info);
        $jason = json_decode($status);

        print_r($jason->success);
        if ($jason->success == 1) {
            $details = json_decode($jason->data, true);
            $zoom_meeting_id = json_decode($details)->id;
            $zoom_meeting_password = json_decode($details)->password;

            LiveClasses::create([
                'date' => strtotime($data['date']),

                'class_id' => $data['class_id'],
                'section_id' => $data['section_id'],
                'subject_id' => $data['subject_id'],
                'meeting_id' => $zoom_meeting_id,
                'meeting_password' => $zoom_meeting_password,
                'attatchment' => $filename,
                'topic' => $data['topic'],
                'waiting_room' => $wait,
                'teacher_id' => auth()->user()->id,
                'school_id' => auth()->user()->school_id,
                'session_id' => $active_session->id,
                'created_at' => strtotime(date('d-m-Y')),
                'updated_at' => strtotime(date('d-m-Y'))
            ]);
        } else {
            return redirect()->route('teacher.list_of_live_class')->with('message', 'Failed.');
        }





        return redirect()->route('teacher.list_of_live_class')->with('message', 'Your meeting has successfully added.');
    }

    public function list_of_live_class()
    {
        $current_time=strtotime(date("m/d/Y"));
        $active_session = Session::where('status', 1)->first();

            $upcoming_classes=LiveClasses::orderBy('id', 'desc')
                                           ->where('school_id', auth()->user()->school_id)
                                           ->where('teacher_id', auth()->user()->id)
                                           ->where('date', '>', $current_time)
                                           ->where('session_id', $active_session->id)
                                           ->get();
            $archive_classes=LiveClasses::orderBy('id', 'desc')
                                           ->where('school_id', auth()->user()->school_id)
                                           ->where('teacher_id', auth()->user()->id)
                                           ->where('date', '<', $current_time)
                                           ->where('session_id', $active_session->id)
                                           ->get();



        return view('teacher.live_class.list_of_live_class', [ 'upcoming_classes'=>$upcoming_classes,'archive_classes'=>$archive_classes]);
    }

    public function list_of_live_class_start($id)
    {


        $live_class_details = $this->get_live_class_by_id($id);

        if ($live_class_details->count() > 0) {



            $live_class_details = $live_class_details->toArray();

            $teacher_details = User::find($live_class_details['teacher_id'])->toArray();
            $live_class_details = $live_class_details;
            $class_details = Classes::find($live_class_details['class_id'])->first()->toArray();
            $subject_details = Subject::find($live_class_details['subject_id'])->first()->toArray();
            $section = Section::find($live_class_details['subject_id'])->first()->toArray();

            $live_class_settings = LiveClassSettings::where('school_id', auth()->user()->school_id)->first()->toArray();

            $total_student = Enrollment::where(array('class_id' => $live_class_details['class_id'], 'school_id' => auth()->user()->school_id, 'session_id' => 1));
            $total_number_of_student = $total_student->count();


            return view('teacher.live_class.zoom_meeting', [
                'live_class_settings' => $live_class_settings, 'subject_details' => $subject_details,
                'class_details' => $class_details, 'live_class_details' => $live_class_details, 'teacher_details' => $teacher_details, 'total_number_of_student' => $total_number_of_student,
                'section' => $section
            ]);
        }
    }

    public function live_class_delete_by_meeting_id(Request $request, $id, $meeting_id)
    {
        $data = $request->all();

        $status = (new CreateZoomMeetings)->delete($meeting_id);
        $delete_meeting = LiveClasses::find($id);
        $delete_meeting->delete();

        return redirect()->route('teacher.list_of_live_class')->with('message', 'Your meeting has deleted successfully.');
    }

    public function live_class_update_by_meeting_id(Request $request)
    {
        $data = $request->all();




        $wait = false;


        if (isset($data['waiting_room'])) {
           $wait=true;
        }


        $meeting_info['meeting_id'] = $data['meeting_id'];
        $meeting_info['topic'] = $data['topic'];
        $meeting_info['start_time'] = strtotime($data['date']);
        $meeting_info['agenda'] = "unknown";
        $meeting_info['waiting_room'] = $wait;

        $status = (new CreateZoomMeetings)->update($meeting_info);

        LiveClasses::where('id', $data['id'])->update([
            'date' => strtotime($data['date']),
            'class_id' => $data['class_id'],
            'section_id' => $data['section_id'],
            'subject_id' => $data['subject_id'],
            'waiting_room' => $wait,
            'topic' => $data['topic']
        ]);

        return redirect()->route('teacher.list_of_live_class')->with('message', 'Your meeting has updated successfully.');
    }

    public function show_edit_modal(Request $request, $id, $meeting_id)
    {
        $data = $request->all();

        $class_details = LiveClasses::find($id);
        return view('teacher.live_class.edit_live_class', ['class_details' => $class_details->toArray()]);

    }



    public function list_of_live_class_student()
    {

        $current_time=strtotime(date("m/d/Y"));
        $student_class_and_section_subject = Enrollment::where('user_id',auth()->user()->id)->first()->toArray();
        $active_session = Session::where('status', 1)->first();
        $class_list = DB::table('live_classes')
            ->orderBy('id', 'desc')
            ->where('school_id', auth()->user()->school_id)
            ->where('class_id',  $student_class_and_section_subject['class_id'])
            ->where('section_id',  $student_class_and_section_subject['section_id'])
            ->where('session_id', $active_session->id)
            ->get();
            $upcoming_classes=LiveClasses::orderBy('id', 'desc')
                                        ->where('school_id', auth()->user()->school_id)
                                        ->where('class_id',  $student_class_and_section_subject['class_id'])
                                        ->where('section_id',  $student_class_and_section_subject['section_id'])
                                        ->where('session_id', $active_session->id)
                                        ->where('date', '>', $current_time)
                                        ->get();

            $archive_classes=LiveClasses::orderBy('id', 'desc')
                                        ->where('school_id', auth()->user()->school_id)
                                        ->where('class_id',  $student_class_and_section_subject['class_id'])
                                        ->where('section_id',  $student_class_and_section_subject['section_id'])
                                        ->where('session_id', $active_session->id)
                                        ->where('date', '<', $current_time)
                                        ->get();


        return view('student.live_class.list_of_live_class', ['list_of_classes' => $class_list->toArray(),'upcoming_classes'=>$upcoming_classes,'archive_classes'=>$archive_classes]);
    }

    public function list_of_live_class_start_student($id)
    {


        $live_class_details = $this->get_live_class_by_id($id);

        if ($live_class_details->count() > 0) {





            $live_class_details = $live_class_details->toArray();

            $teacher_details = User::find($live_class_details['teacher_id'])->toArray();
            $live_class_details = $live_class_details;
            $class_details = Classes::find($live_class_details['class_id'])->first()->toArray();
            $subject_details = Subject::find($live_class_details['subject_id'])->first()->toArray();
            $section =Section::find($live_class_details['subject_id'])->first()->toArray();



            $live_class_settings = LiveClassSettings::where('school_id', auth()->user()->school_id)->first()->toArray();


            $total_student= Enrollment::where(array('class_id' => $live_class_details['class_id'], 'school_id' =>auth()->user()->school_id, 'session_id' =>1));
            $total_number_of_student= $total_student->count();


            return view('student.live_class.zoom_meeting', [
                'live_class_settings' => $live_class_settings, 'subject_details' => $subject_details,
                'class_details' => $class_details, 'live_class_details' => $live_class_details, 'teacher_details' => $teacher_details,'total_number_of_student' => $total_number_of_student,
                'section'=>$section
            ]);
        }
    }

    public function get_live_class_by_id($id)
    {
        $checker = array();
        if (auth()->user()->role_id == 3)
        {

            $checker = ['id' => $id, 'school_id' => auth()->user()->school_id, 'teacher_id' =>  auth()->user()->id, 'session_id' => 1];
        } elseif (auth()->user()->role_id == 7)
        {
            $student_data = Enrollment::where('user_id', auth()->user()->id)->first();
            $checker = ['id' => $id, 'school_id' =>  auth()->user()->school_id, 'class_id' => $student_data->class_id, 'session_id' => 1];
        }

        $data = LiveClasses::where($checker)->first();
        return $data;
    }









}
