<?php

namespace App\Http\Controllers\Addon;

use App\Http\Controllers\Controller;

use App\Traits\ZoomMeetingTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CreateZoomMeetings extends Controller
{
    use ZoomMeetingTrait;
    const MEETING_TYPE_INSTANT = 1;
    const MEETING_TYPE_SCHEDULE = 2;
    const MEETING_TYPE_RECURRING = 3;
    const MEETING_TYPE_FIXED_RECURRING_FIXED = 8;


    //Showing the available meeting list
    public function list(Request $request)
    {
        $path = 'users/me/meetings';
        $response = $this->zoomGet($path);

        $data = json_decode($response->body(), true);
        $data['meetings'] = array_map(function (&$m) {
            $m['start_at'] = $this->toUnixTimeStamp($m['start_time'], $m['timezone']);
            return $m;
        }, $data['meetings']);

        return [
            'success' => $response->ok(),
            'data' => $data,
        ];
    }

    public function create($meeting_info)
    {

        $data = $meeting_info;

        $path = 'users/me/meetings';
        $response = $this->zoomPost($path, [
            'topic' => $data['topic'],
            'type' => self::MEETING_TYPE_SCHEDULE,
            'start_time' => $this->toZoomTimeFormat($data['start_time']),
            'duration' => 40,
            'agenda' => $data['agenda'],
            'settings' => [
                'host_video' => true,
                'participant_video' => true,
                'waiting_room' => $data['waiting_room'],
            ]
        ]);


        $var =  [
            'success' => $response->status() === 201,
            'data' => json_encode($response->body(), true),
        ];

        return json_encode($var, true);
    }

    public function get(Request $request, string $id)
    {
        $path = 'meetings/' . $id;
        $response = $this->zoomGet($path);

        $data = json_decode($response->body(), true);
        if ($response->ok()) {
            $data['start_at'] = $this->toUnixTimeStamp($data['start_time'], $data['timezone']);
        }

        return [
            'success' => $response->ok(),
            'data' => $data,
        ];
    }

    public function update($meeting_info)
    {
        $data = $meeting_info;



        $path = 'meetings/' . $data['meeting_id'];
        $response = $this->zoomPatch($path, [
            'topic' => $data['topic'],
            'type' => self::MEETING_TYPE_SCHEDULE,
            'start_time' => $this->toZoomTimeFormat($data['start_time']),
            'duration' => 40,
            'agenda' => $data['agenda'],
            'settings' => [
                'host_video' => true,
                'participant_video' => true,
                'waiting_room' => $data['waiting_room'],
            ]
        ]);

        $var =  [
            'success' => $response->status() === 201,
            'data' => json_encode($response->body(), true),
        ];

        return json_encode($var, true);
    }

    public function delete(string $id)
    {
        $path = 'meetings/' . $id;
        $response = $this->zoomDelete($path);

        $var =  [
            'success' => $response->status() === 201,
            'data' => json_encode($response->body(), true),
        ];

        return json_encode($var, true);
    }
}
