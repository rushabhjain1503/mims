<?php

namespace App\Models\Addon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LiveClassSettings extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $fillable = [
        'id', 'zoom_api_key', 'zoom_secrect_key', 'school_id'
    ];
}
