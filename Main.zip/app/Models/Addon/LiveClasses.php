<?php

namespace App\Models\Addon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class LiveClasses extends Model
{
    use HasFactory;

    protected $fillable = [
        'id', 'class_id', 'subject_id', 'section_id', 'date', 'time', 'teacher_id', 'meeting_id', 'meeting_password', 'meeting_type', 'topic', 'attatchment', 'waiting_room','school_id', 'session_id', 'created_at'
    ];
}

