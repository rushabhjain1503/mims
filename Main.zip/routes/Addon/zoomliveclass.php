<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Addon\ZoomLiveClass;




    // Zoom Live Class
Route::controller(ZoomLiveClass::class)->group(function () {

    // Admin
    Route::get('admin/live_class_settings', 'live_class_settings')->name('admin.live_class_key');
    Route::post('admin/live_class_settings/update/{id}', 'live_class_settings_update')->name('admin.live_class_key.update');

    // Teacher
    Route::get('teacher/add_live_class', 'add_live_class')->name('teacher.add_live_class');
    Route::post('teacher/add_live_classes', 'live_class_adding')->name('teacher.live_class_adding');
    Route::get('teacher/list_of_live_class', 'list_of_live_class')->name('teacher.list_of_live_class');
    Route::get('teacher/list_of_live_class/start/{id}', 'list_of_live_class_start')->name('teacher.list_of_live_class_start');
    Route::get('teacher/deleting_live_class/{id}/{meeting_id}', 'live_class_delete_by_meeting_id')->name('teacher.live_class_delete_by_meeting_id');
    Route::post('teacher/updating_live_class/', 'live_class_update_by_meeting_id')->name('teacher.live_class_update_by_meeting_id');
    Route::get('teacher/edit/liveClass/{id}/{meeting_id}', 'show_edit_modal')->name('teacher.show_edit_modal');

    // Student
    Route::get('student/list_of_live_class', 'list_of_live_class_student')->name('student.list_of_live_class');
    Route::get('student/list_of_live_class/start/{id}', 'list_of_live_class_start_student')->name('student.list_of_live_class_start');
});



